const fncE = () => {
	console.log("fncC");
}

export default fncE;