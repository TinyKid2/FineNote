const fncC = () => {
	console.log("fncC");
}

const fncD = () => {
	console.log("fncB");
}

export {
  fncC,
  fncD
}