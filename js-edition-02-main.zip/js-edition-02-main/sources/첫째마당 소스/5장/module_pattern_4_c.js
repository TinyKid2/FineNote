import { fncA, fncB, msg } from './module_pattern_1_c.js';
import { fncC, fncD } from './module_pattern_2_c.js';
import fncE from './module_pattern_3_c.js';

fncA();
fncB();
console.log(msg);

fncC();
fncD();

fncE();