export const fncA = () => {
	console.log("fncA");
}

export const fncB = () => {
	console.log("fncB");
}

export const msg = "hello";